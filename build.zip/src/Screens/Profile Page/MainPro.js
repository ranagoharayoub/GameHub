import React from 'react'
import HeroFade from './HeroFade'
import Profile from './Profile'

export default function MainPro() {
    return (
        <>  
            <HeroFade />
            <Profile />    
        </>
    )
}
